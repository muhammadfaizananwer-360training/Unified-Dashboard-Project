export const FETCH_BRAND = 'fetch_brand';
export const TOP_MENU = 'top_menu';
export const LEFT_MENU = 'left_menu';
