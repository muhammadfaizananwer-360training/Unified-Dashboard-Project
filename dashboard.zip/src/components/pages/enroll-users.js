import React, { Component } from 'react';

class EnrollUsers extends Component {
  render() {
    return (
      <div>
        Enroll Users
      </div>
    );
  }
}

export default EnrollUsers;
