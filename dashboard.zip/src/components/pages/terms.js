import React, { Component } from 'react';

class Terms extends Component {
  render() {
    return (
      <div>
        Terms
      </div>
    );
  }
}

export default Terms;
