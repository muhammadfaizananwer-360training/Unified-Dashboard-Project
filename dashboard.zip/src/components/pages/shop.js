import React, { Component } from 'react';

class Shop extends Component {
  render() {
    return (
      <div>
        Shop
      </div>
    );
  }
}

export default Shop;
