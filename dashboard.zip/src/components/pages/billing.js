import React, { Component } from 'react';

class Billing extends Component {
  render() {
    return (
      <div>
        Billing
      </div>
    );
  }
}

export default Billing;
