import React, { Component } from 'react';

class CreateCourse extends Component {
  render() {
    return (
      <div>
        Create Course
      </div>
    );
  }
}

export default CreateCourse;
