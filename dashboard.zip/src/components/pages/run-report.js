import React, { Component } from 'react';

class RunReport extends Component {
  render() {
    return (
      <div>
        Run Report
      </div>
    );
  }
}

export default RunReport;
