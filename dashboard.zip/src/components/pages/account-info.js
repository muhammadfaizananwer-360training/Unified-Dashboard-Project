import React, { Component } from 'react';

class AccountInfo extends Component {
  render() {
    return (
      <div>
        Account Info
      </div>
    );
  }
}

export default AccountInfo;
