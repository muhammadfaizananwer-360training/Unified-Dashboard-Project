import React, { Component } from 'react';

class AddressBook extends Component {
  render() {
    return (
      <div>
        Address Book
      </div>
    );
  }
}

export default AddressBook;
