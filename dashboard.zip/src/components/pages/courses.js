import React, { Component } from 'react';

class Courses extends Component {
  render() {
    return (
      <div>
        My Courses
      </div>
    );
  }
}

export default Courses;
