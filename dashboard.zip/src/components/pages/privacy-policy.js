import React, { Component } from 'react';

class PrivacyPolicy extends Component {
  render() {
    return (
      <div>
        Privacy Policy
      </div>
    );
  }
}

export default PrivacyPolicy;
