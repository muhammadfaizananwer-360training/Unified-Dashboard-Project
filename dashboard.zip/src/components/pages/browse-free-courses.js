import React, { Component } from 'react';

class BrowseFreeCourses extends Component {
  render() {
    return (
      <div>
        Browse Free Courses
      </div>
    );
  }
}

export default BrowseFreeCourses;
