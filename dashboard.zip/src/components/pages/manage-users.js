import React, { Component } from 'react';

class ManageUsers extends Component {
  render() {
    return (
      <div>
        Manage Users
      </div>
    );
  }
}

export default ManageUsers;
