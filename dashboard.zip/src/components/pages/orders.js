import React, { Component } from 'react';

class Orders extends Component {
  render() {
    return (
      <div>
        Orders
      </div>
    );
  }
}

export default Orders;
