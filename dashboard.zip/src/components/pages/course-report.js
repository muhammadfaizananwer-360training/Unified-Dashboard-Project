import React, { Component } from 'react';

class CourseReport extends Component {
  render() {
    return (
      <div>
        Course Report
      </div>
    );
  }
}

export default CourseReport;
