import React, { Component } from 'react';

class Subscriptions extends Component {
  render() {
    return (
      <div>
        My Subscriptions
      </div>
    );
  }
}

export default Subscriptions;
