import React, { Component } from 'react';

class Support extends Component {
  render() {
    return (
      <div>
        Support
      </div>
    );
  }
}

export default Support;
